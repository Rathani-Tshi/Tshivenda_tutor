// src/quizService.js
import { supabase } from './supabaseClient';

export async function loadQuizzes() {
  const { data, error } = await supabase
    .from('Quizzes')
    .select(`
      id,
      title,
      description,
      grade,
      questions (
        id,
        type,
        prompt,
        mcq_options (
          id,
          option_text,
          is_correct
        ),
        fill_in_answers (
          id,
          answer_text
        )
      )
    `);

  if (error) {
    console.error('Error loading quizzes:', error);
    return [];
  }

  return data;
}