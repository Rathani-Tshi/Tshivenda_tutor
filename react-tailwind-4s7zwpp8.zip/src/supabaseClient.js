import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://rmsvkjigwatveuwstvoo.supabase.co";
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJtc3Zramlnd2F0dmV1d3N0dm9vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDY2MzM1MjUsImV4cCI6MjA2MjIwOTUyNX0.ThGPnXg99-QSNGq9Nhb8BseRBRnCpqPlyHBcBc4hpG4";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);