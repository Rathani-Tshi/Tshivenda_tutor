import React, { useEffect, useState } from 'react';
import { supabase } from './supabaseClient';

function Auth({ onLogin }) {
  const handleLogin = async () => {
    const email = prompt('Enter your email'); // only typing needed
    if (!email) return;
    const { error } = await supabase.auth.signInWithOtp({ email });
    if (error) alert('Error sending link: ' + error.message);
    else alert('Check your email for the login link!');
  };

  return (
    <div className="p-4">
      <h2 className="text-xl mb-4">Login or Register</h2>
      <button onClick={handleLogin} className="p-2 bg-blue-500 text-white rounded">
        Send Magic Link
      </button>
    </div>
  );
}

function Dashboard({ user, onSelectQuiz }) {
  const [quizzes, setQuizzes] = useState([]);
  const [grades, setGrades] = useState({});

  useEffect(() => {
    // Fetch quizzes
    supabase.from('quizzes').select('id, title, translation').then(({ data }) => {
      if (data) setQuizzes(data);
    });

    // Fetch grades
    supabase
      .from('grades')
      .select('quiz_id, score')
      .eq('user_id', user.id)
      .then(({ data }) => {
        const map = {};
        data?.forEach(g => (map[g.quiz_id] = g.score));
        setGrades(map);
      });
  }, [user]);

  return (
    <div className="p-4">
      <h2 className="text-xl mb-4">Welcome, {user.email}</h2>
      <h3 className="mb-2 font-bold">Your Grades:</h3>
      {quizzes.map(q => (
        <div key={q.id}>
          {q.title}: {grades[q.id] ?? '—'}
        </div>
      ))}
      <h3 className="mt-4 font-bold">Select a Quiz:</h3>
      {quizzes.map(q => (
        <button
          key={q.id}
          onClick={() => onSelectQuiz(q.id)}
          className="block p-2 mt-2 border rounded hover:bg-gray-100"
        >
          <div className="font-semibold">{q.title}</div>
          <div className="text-sm text-gray-600">{q.translation}</div>
        </button>
      ))}
    </div>
  );
}

function Quiz({ quizId, onDone }) {
  const [questions, setQuestions] = useState([]);
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);

  useEffect(() => {
    supabase
      .from('questions')
      .select('*')
      .eq('quiz_id', quizId)
      .then(({ data }) => setQuestions(data ?? []));
  }, [quizId]);

  if (questions.length === 0) return <div className="p-4">Loading questions…</div>;

  const q = questions[current];

  const handleAnswer = (option) => {
    if (option === q.answer) setScore(prev => prev + 1);
    if (current + 1 < questions.length) {
      setCurrent(current + 1);
    } else {
      // Save score
      const userId = supabase.auth.getUser().then(res => {
        const uid = res.data.user.id;
        supabase.from('grades').upsert({
          user_id: uid,
          quiz_id: quizId,
          score
        }).then(onDone);
      });
    }
  };

  return (
    <div className="p-4">
      <div className="mb-2">Question {current + 1} of {questions.length}</div>
      <div className="font-semibold">{q.question_en}</div>
      <div className="italic text-gray-600 mb-4">{q.question_ve}</div>
      <div className="grid grid-cols-2 gap-2">
        {q.options.map(opt => (
          <button key={opt} onClick={() => handleAnswer(opt)} className="p-2 border rounded hover:bg-gray-100">
            {opt}
          </button>
        ))}
      </div>
    </div>
  );
}

function App() {
  const [user, setUser] = useState(null);
  const [quizId, setQuizId] = useState(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data?.user));
    supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user ?? null);
    });
  }, []);

  if (!user) return <Auth onLogin={() => supabase.auth.getUser().then(({ data }) => setUser(data.user))} />;
  if (quizId) return <Quiz quizId={quizId} onDone={() => setQuizId(null)} />;
  return <Dashboard user={user} onSelectQuiz={setQuizId} />;
}

export default App;